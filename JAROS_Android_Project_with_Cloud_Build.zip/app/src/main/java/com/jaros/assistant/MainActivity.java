package com.jaros.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.Color;
import android.util.TypedValue;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 41;
    private TextView status;
    private TextView transcript;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 25, 43));
        getWindow().setNavigationBarColor(Color.rgb(12, 25, 43));

        tts = new TextToSpeech(this, result -> {
            if (result != TextToSpeech.ERROR) tts.setLanguage(new Locale("ru", "RU"));
        });

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(26), dp(22), dp(22));
        page.setBackgroundColor(Color.rgb(12, 25, 43));

        TextView brand = text("ЖАРОС", 30, Color.WHITE, true);
        page.addView(brand);
        TextView subtitle = text("Универсальная платформа управления", 14, Color.rgb(180,195,215), false);
        page.addView(subtitle);

        status = text("Система запущена · деморежим", 13, Color.rgb(117,220,174), false);
        status.setPadding(0, dp(18), 0, dp(12));
        page.addView(status);

        Button voice = new Button(this);
        voice.setText("🎙  ГОВОРИТЬ С ЖАРОС");
        voice.setTextSize(17);
        voice.setAllCaps(false);
        voice.setOnClickListener(v -> listen());
        page.addView(voice, new LinearLayout.LayoutParams(-1, dp(64)));

        transcript = text("Нажми кнопку и произнеси команду.\nНапример: «Проверь почту» или «Какая погода?»", 15, Color.WHITE, false);
        transcript.setPadding(dp(14), dp(18), dp(14), dp(18));
        page.addView(transcript);

        TextView modules = text("ПОДКЛЮЧАЕМЫЕ НАПРАВЛЕНИЯ", 12, Color.rgb(155,177,204), true);
        modules.setPadding(0, dp(18), 0, dp(10));
        page.addView(modules);

        String[][] items = {
            {"Дом и устройства", "Свет · чайник · кофемашина · климат"},
            {"Телефон и связь", "Звонки · сообщения · контакты"},
            {"Почта и документы", "Чтение · сортировка · подготовка ответов"},
            {"Интернет и информация", "Погода · поиск · курсы валют"},
            {"Финансы", "Банки · платежи · покупки"},
            {"Криптовалюты", "Котировки · портфели · кошельки"},
            {"Автомобиль и техника", "Машина · компьютер · оборудование"},
            {"Идеи и разработка", "Проекты · заметки · совместная работа"}
        };
        for (String[] item : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackgroundColor(Color.rgb(24, 42, 65));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(8);
            page.addView(card, cp);
            card.addView(text(item[0], 16, Color.WHITE, true));
            TextView detail = text(item[1], 12, Color.rgb(177,193,214), false);
            detail.setPadding(0, dp(4), 0, 0);
            card.addView(detail);
        }

        TextView note = text("Сейчас это стартовый прототип интерфейса. Реальные подключения к почте, устройствам, банкам и ИИ требуют серверного ядра, авторизации и отдельных разрешений.", 12, Color.rgb(177,193,214), false);
        note.setPadding(0, dp(14), 0, dp(10));
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void listen() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите команду для ЖАРОС");
        try {
            startActivityForResult(intent, VOICE_REQUEST);
        } catch (Exception e) {
            status.setText("На устройстве не найден сервис распознавания речи.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handleCommand(results.get(0));
        }
    }

    private void handleCommand(String command) {
        transcript.setText("Вы сказали:\n«" + command + "»");
        String q = command.toLowerCase(new Locale("ru", "RU"));
        String answer;
        if (q.contains("погод")) answer = "Запрос погоды распознан. Для реального прогноза нужно подключить погодный сервис.";
        else if (q.contains("почт") || q.contains("письм")) answer = "Запрос почты распознан. Подключение почтового аккаунта пока не настроено.";
        else if (q.contains("курс") || q.contains("битко") || q.contains("bitcoin")) answer = "Финансовый запрос распознан. Источник рыночных данных ещё не подключён.";
        else if (q.contains("чайник") || q.contains("кофе") || q.contains("свет")) answer = "Команда управления устройством распознана. Для выполнения нужно подключить устройство и выдать ему разрешение.";
        else if (q.contains("позвон")) answer = "Команда звонка распознана. Телефония пока не подключена.";
        else answer = "Я распознал команду. Пока доступен демонстрационный режим; исполнитель действий будет подключён на следующем этапе.";
        status.setText("Команда принята · деморежим");
        transcript.append("\n\nЖАРОС: " + answer);
        if (tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jaros_reply");
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
