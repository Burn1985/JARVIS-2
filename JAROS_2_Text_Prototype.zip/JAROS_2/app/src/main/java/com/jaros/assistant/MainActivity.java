package com.jaros.assistant;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private EditText request;
    private TextView result;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,25,43));
        getWindow().setNavigationBarColor(Color.rgb(12,25,43));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(24));
        page.setBackgroundColor(Color.rgb(12,25,43));

        page.addView(label("ЖАРОС 2", 30, Color.WHITE, true));
        page.addView(label("Текстовый прототип · маршрутизация команд", 14, Color.rgb(180,195,215), false));
        status = label("Готов к работе · версия 0.2.0", 13, Color.rgb(117,220,174), false);
        status.setPadding(0, dp(16), 0, dp(12));
        page.addView(status);

        request = new EditText(this);
        request.setSingleLine(false);
        request.setMinLines(2);
        request.setTextSize(16);
        request.setHint("Например: Какая погода завтра в Штутгарте?");
        request.setHintTextColor(Color.GRAY);
        request.setTextColor(Color.WHITE);
        request.setPadding(dp(14), dp(12), dp(14), dp(12));
        request.setBackgroundColor(Color.rgb(29,48,72));
        page.addView(request, new LinearLayout.LayoutParams(-1, -2));

        Button run = new Button(this);
        run.setText("ВЫПОЛНИТЬ ЗАПРОС");
        run.setAllCaps(false);
        run.setOnClickListener(v -> route(request.getText().toString()));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(56));
        rp.topMargin = dp(10);
        page.addView(run, rp);

        TextView quickTitle = label("БЫСТРЫЕ КОМАНДЫ", 12, Color.rgb(155,177,204), true);
        quickTitle.setPadding(0, dp(20), 0, dp(8));
        page.addView(quickTitle);
        addQuick(page, "Погода в Weissach", "Какая погода в Weissach?");
        addQuick(page, "Открыть календарь", "Открой календарь");
        addQuick(page, "Будильник на 07:00", "Поставь будильник на 07:00");
        addQuick(page, "Поиск Google", "Найди в Google последние новости технологий");
        addQuick(page, "Поиск YouTube", "Найди на YouTube обзор Android");

        TextView outTitle = label("ОТВЕТ ЖАРОСА", 12, Color.rgb(155,177,204), true);
        outTitle.setPadding(0, dp(20), 0, dp(8));
        page.addView(outTitle);
        result = label("Здесь появится результат выполнения команды.", 15, Color.WHITE, false);
        result.setPadding(dp(14), dp(14), dp(14), dp(14));
        result.setBackgroundColor(Color.rgb(24,42,65));
        page.addView(result);

        TextView note = label("Важно: это экспериментальный прототип. Погода и поиск открываются через веб-сервисы; календарь и будильник передают команду Android. Подключения к нескольким ИИ и общему интернет-поиску пока не настроены — для них понадобится серверное ядро и защищённые API-ключи.", 12, Color.rgb(177,193,214), false);
        note.setPadding(0, dp(16), 0, 0);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void addQuick(LinearLayout page, String title, String command) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setOnClickListener(v -> { request.setText(command); route(command); });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.bottomMargin = dp(5);
        page.addView(b, p);
    }

    private void route(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) { show("Напиши запрос — например, попроси открыть календарь или найти что-нибудь в Google."); return; }
        String s = q.toLowerCase(new Locale("ru", "RU"));
        try {
            if (s.contains("погод") || s.contains("weather")) {
                String place = extractPlace(q, "погод[ауы]?\\s+(?:в|для)\\s+(.+)$");
                openWeb("https://www.google.com/search?q=" + enc("погода " + (place.isEmpty() ? "" : place)));
                show("Открываю поиск погоды" + (place.isEmpty() ? "" : " для " + place) + ". Прогноз загружается в браузере.");
            } else if (s.contains("будильник") || s.contains("разбуди") || s.contains("alarm")) {
                Matcher m = Pattern.compile("(\\d{1,2})[:.](\\d{2})").matcher(q);
                if (!m.find()) { show("Не понял время. Напиши, например: «Поставь будильник на 07:30»."); return; }
                int hour = Integer.parseInt(m.group(1));
                int minute = Integer.parseInt(m.group(2));
                if (hour > 23 || minute > 59) { show("Проверь время: часы от 00 до 23, минуты от 00 до 59."); return; }
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                i.putExtra(AlarmClock.EXTRA_HOUR, hour);
                i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
                i.putExtra(AlarmClock.EXTRA_MESSAGE, "ЖАРОС");
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
                startActivity(i);
                show(String.format(Locale.getDefault(), "Передал Android команду создать будильник на %02d:%02d. Проверь и подтверди его в приложении часов.", hour, minute));
            } else if (s.contains("календар") || s.contains("calendar")) {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_APP_CALENDAR);
                try { startActivity(i); show("Открываю календарь Android."); }
                catch (ActivityNotFoundException e) { openWeb("https://calendar.google.com/"); show("Отдельное приложение календаря не найдено. Открываю Google Calendar в браузере."); }
            } else if (s.contains("youtube") || s.contains("ютуб") || s.contains("видео")) {
                String term = q.replaceAll("(?i)youtube|ютуб|найди|найти|поиск|видео|на", " ").trim();
                openWeb("https://www.youtube.com/results?search_query=" + enc(term.isEmpty() ? q : term));
                show("Открываю результаты поиска YouTube.");
            } else if (s.contains("google") || s.contains("гугл") || s.contains("найди") || s.contains("найти") || s.contains("поищи") || s.contains("поиск")) {
                String term = q.replaceAll("(?i)google|гугл|найди|найти|поищи|в интернете|в интернет|поиск", " ").trim();
                openWeb("https://www.google.com/search?q=" + enc(term.isEmpty() ? q : term));
                show("Открываю поиск Google.");
            } else if (s.contains("почт") || s.contains("email") || s.contains("письмо")) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:"));
                startActivity(i);
                show("Открываю почтовое приложение. Чтение и отправка писем пока не подключены.");
            } else if (s.contains("ии") || s.contains("нейросет") || s.contains("claude") || s.contains("chatgpt") || s.contains("gemini")) {
                show("Запрос относится к ИИ. В версии 2 предусмотрим единый диспетчер моделей (ChatGPT, Claude, Gemini и другие), но реальные API-подключения ещё не настроены.");
            } else {
                openWeb("https://www.google.com/search?q=" + enc(q));
                show("Не нашёл отдельный исполнитель для этой команды. Не теряю запрос — отправляю его в веб-поиск Google.");
            }
        } catch (Exception e) {
            show("Не удалось выполнить действие: " + e.getClass().getSimpleName() + ". Проверь, установлено ли подходящее приложение и доступен ли интернет.");
        }
    }

    private String extractPlace(String q, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(q);
        return m.find() ? m.group(1).trim() : "";
    }
    private void openWeb(String url) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
    private String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (Exception e) { return s.replace(" ", "+"); }
    }
    private void show(String message) {
        status.setText("Запрос обработан маршрутизатором");
        result.setText(message);
    }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
